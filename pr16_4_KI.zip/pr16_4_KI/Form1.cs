﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace pr16_4_KI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (File.Exists("spisok.txt"))
            {
                int n = Convert.ToInt32(numericUpDown1.Value);
                List<Country> countries = File.ReadAllLines("spisok.txt")
                    .Select(line => line.Split(' '))
                    .Select(parts => new Country { Name = parts[0], Popul = Convert.ToInt32(parts[1]) }).ToList();
                var sorted = countries.Where(c => c.Popul > n)
                    .OrderBy(s => s.Name.Length)
                    .ThenBy(s => s.Name)
                    .ToList();

                foreach (var country in sorted)
                {
                    listBox1.Items.Add($"{country.Name} {country.Popul}");
                }
            }
            else { MessageBox.Show("такого файла"); }

        }
    }
}
